#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="${1:-$PWD}"
PATCH_DIR="$PACKAGE_DIR/patch"

if [[ ! -f "$TARGET_DIR/artisan" ]]; then
    echo "ERROR: artisan tidak ditemukan di: $TARGET_DIR"
    echo "Masuk ke folder project Laravel lalu jalankan kembali script ini."
    exit 1
fi

BACKUP_DIR="$TARGET_DIR/backup_validasi_tiket_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

echo "Membuat backup file lama di: $BACKUP_DIR"
while IFS= read -r -d '' source_file; do
    relative_path="${source_file#$PATCH_DIR/}"
    target_file="$TARGET_DIR/$relative_path"

    if [[ -f "$target_file" ]]; then
        mkdir -p "$BACKUP_DIR/$(dirname "$relative_path")"
        cp "$target_file" "$BACKUP_DIR/$relative_path"
    fi

done < <(find "$PATCH_DIR" -type f -print0)

echo "Menyalin file perbaikan..."
cp -R "$PATCH_DIR"/. "$TARGET_DIR"/

# Hapus implementasi custom Page/Blade lama supaya tidak bentrok dengan Resource Filament.
rm -f "$TARGET_DIR/app/Filament/Pages/ValidasiTiket.php"
rm -f "$TARGET_DIR/resources/views/filament/pages/validasi-tiket.blade.php"

echo "Memeriksa sintaks file utama..."
php -l "$TARGET_DIR/app/Providers/Filament/AdminPanelProvider.php"
php -l "$TARGET_DIR/app/Filament/Resources/ValidasiTikets/ValidasiTiketResource.php"
php -l "$TARGET_DIR/app/Filament/Resources/ValidasiTikets/Pages/ManageValidasiTikets.php"
php -l "$TARGET_DIR/app/Services/TicketValidationService.php"

echo
echo "File perbaikan berhasil dipasang."
echo "Backup tersimpan di: $BACKUP_DIR"
echo
echo "Lanjutkan dengan:"
echo "  composer install"
echo "  php artisan optimize:clear"
echo "  php artisan migrate"
echo "  php artisan route:list --path=validasi-tikets"
